package com.example.cinematixrecycleview

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cinematixrecycleview.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val movieList = mutableListOf(
            Movie("The Greatest Showman",R.drawable.thegreatestshowman, R.string.def, 4.9,"Andrew Stanton",listOf("Kids", "Animation")),
            Movie("Interstellar",R.drawable.interstellar,R.string.def, 4.8,"Andrew Stanton",listOf("Kids", "Animation")),
            Movie("Litle Women",R.drawable.lilwomen,R.string.def, 4.6,"Guy Ritchie",listOf("Kids", "Animation")),
            Movie("Oppenheimer",R.drawable.oppenheimer,R.string.def, 4.9,"John Lasseter, Tim Allen, Andrew Stanton",listOf("Kids", "Animation"))
        )

        val adapter = MovieAdapter(movieList) { clickedMovie ->
            val intent = Intent(requireContext(), MovieDetail::class.java)
            intent.putExtra("movieData", clickedMovie)
            startActivity(intent)
        }

//        binding.rvMovies.layoutManager = LinearLayoutManager(requireContext())

        binding.rvMovies.adapter = adapter

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}